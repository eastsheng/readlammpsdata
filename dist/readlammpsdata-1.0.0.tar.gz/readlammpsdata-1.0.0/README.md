# readlammpsdata
A script for reading lammps data
